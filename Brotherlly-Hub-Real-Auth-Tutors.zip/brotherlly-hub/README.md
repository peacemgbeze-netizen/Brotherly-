# Brotherlly Hub

A Next.js student-learning platform with real Firebase email/password authentication, password reset, email verification, a Gemini-powered study tutor, and a Firestore-backed tutor directory/session-request workflow.

## Included real flows

- Firebase Authentication: account creation, sign-in, sign-out, password-reset email, and verification email.
- Student and tutor account roles.
- Tutor profile editing (intro + subjects) for administrator-approved tutors. New tutor accounts remain hidden until an administrator reviews and sets `tutorApproved: true` in Firestore.
- Tutor directory reads registered profiles from Firestore.
- Session requests are written to Firestore with `pending` status. This is a request, not a confirmed booking or payment.
- Gemini requests run on the server and require a verified Firebase ID token.
- Server-only `GEMINI_API_KEY`; basic per-user request limiting, input limits, timeout handling, generic provider errors, and security headers.
- Firestore security rules restrict profile changes and tutor session-request access.

## 1. Firebase setup (required for real accounts)

1. Open the Firebase Console and create/select your project.
2. In **Authentication → Sign-in method**, enable **Email/Password**.
3. In **Authentication → Settings → Authorized domains**, add your Vercel production domain and preview domains you use.
4. Create a **Cloud Firestore** database.
5. Register a Firebase Web App in Project settings and copy its configuration into `.env.local`.
6. Deploy the supplied rules: install Firebase CLI, run `firebase login`, then `firebase deploy --only firestore:rules` from this folder.
7. Ensure your Firebase project's email verification template is enabled/customized as needed.

## 2. Gemini API setup

Create a key in Google AI Studio and put it in `.env.local` as `GEMINI_API_KEY`. Never prefix it with `NEXT_PUBLIC_`, commit it, or put it in browser code.

## 3. Firebase Admin credential for server-side token verification

The `/api/tutor` endpoint verifies Firebase ID tokens using Firebase Admin. Create a dedicated service account in Google Cloud IAM for this Firebase project, grant only the minimum required Firebase Authentication verification permissions, and store its service-account JSON as a single-line JSON string in `FIREBASE_SERVICE_ACCOUNT_JSON`.

- Do not use a service-account key in client code or `NEXT_PUBLIC_` variables.
- Do not upload the service-account JSON to GitHub or include real credentials in the ZIP.
- Prefer a managed identity / Application Default Credentials where your deployment environment supports it. For Vercel, a dedicated restricted service account secret is the practical fallback.
- Rotate the service-account key if it is exposed.

## 4. Environment variables

The ZIP includes a blank `.env.local` template and `.env.example`. Fill in the values locally. `.env.local` is ignored by Git.

```env
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=
NEXT_PUBLIC_FIREBASE_PROJECT_ID=
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=
NEXT_PUBLIC_FIREBASE_APP_ID=
GEMINI_API_KEY=
GEMINI_MODEL=gemini-2.5-flash
FIREBASE_SERVICE_ACCOUNT_JSON=
```

On Vercel, add the same values in **Project → Settings → Environment Variables**, then redeploy. A local `.env.local` file does not automatically configure Vercel.

## 5. Install and run

Requires Node.js 20.9+.

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

Before deploying, run:

```bash
npm run build
npm run lint
```

## Important production notes

- Do not advertise a feature as live unless its external service is configured and tested.
- The tutor session flow creates real pending requests, and approved tutors have an inbox to accept or decline them. Email notifications, a safe in-platform messaging system, and an administrator review dashboard are not yet implemented. Do not treat a request as a confirmed booking.
- The current in-memory API limiter is a basic guard, not a distributed abuse-prevention system. Use a managed rate limiter and monitoring before broad public launch.
- The remaining exam questions, marketplace, community, maps, payment/subscription and events sections may still contain preview/sample content. Verify them before accepting payments or representing them as live services.
- Security headers are set in `next.config.ts`. A strict Content Security Policy, App Check, audit logging, automated tests, abuse reporting and privacy/terms pages should be added before a high-risk public launch.
- Firebase client configuration is not a secret; Firestore rules and Auth control access. Gemini and service-account credentials are secret.
