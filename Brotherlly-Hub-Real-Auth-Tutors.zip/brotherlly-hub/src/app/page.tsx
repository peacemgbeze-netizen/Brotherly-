"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import AuthGate from "../components/AuthGate";
import TutorsDirectory from "../components/TutorsDirectory";
import { useAuth } from "../lib/auth-context";
import { auth } from "../lib/firebase";
import {
  Activity, ArrowRight, ArrowUpRight, Bell, BookOpen,
  BrainCircuit, CalendarDays, Check, ChevronDown,
  ChevronRight, CircleHelp, Clock3, Compass, GraduationCap, LayoutDashboard,
  MapPin, Menu, Mic, Volume2, Search, Settings, ShieldCheck, ShoppingBag,
  Sparkles, Target, Trophy, Users, X, Zap
} from "lucide-react";

type Section = "Overview" | "Exam Centre" | "CBT Practice" | "Study Notes" | "Brotherly" | "Tutors" | "Schools & Campus" | "Community" | "Events & Opportunities" | "Marketplace" | "My Profile";
const navGroups: { title: string; items: { label: Section; icon: typeof LayoutDashboard; tag?: string }[] }[] = [
  { title: "LEARN", items: [
    { label: "Overview", icon: LayoutDashboard },
    { label: "Exam Centre", icon: GraduationCap },
    { label: "CBT Practice", icon: Target, tag: "CBT" },
    { label: "Study Notes", icon: BookOpen },
    { label: "Brotherly", icon: BrainCircuit, tag: "AI" },
    { label: "Tutors", icon: Users, tag: "LIVE" }
  ]},
  { title: "CONNECT", items: [
    { label: "Schools & Campus", icon: MapPin },
    { label: "Community", icon: Users },
    { label: "Events & Opportunities", icon: CalendarDays },
    { label: "Marketplace", icon: ShoppingBag }
  ]},
  { title: "ACCOUNT", items: [{ label: "My Profile", icon: Settings }] }
];

const subjects = [
  { name: "Mathematics", code: "MTH", progress: 68, color: "violet", icon: "∑" },
  { name: "English Language", code: "ENG", progress: 82, color: "blue", icon: "Aa" },
  { name: "Biology", code: "BIO", progress: 46, color: "green", icon: "⌁" },
  { name: "Chemistry", code: "CHM", progress: 31, color: "orange", icon: "⚗" }
];

const questions = [
  { subject: "Biology", q: "Which organelle is primarily responsible for aerobic respiration in a cell?", options: ["Ribosome", "Mitochondrion", "Golgi apparatus", "Lysosome"], answer: 1, explain: "Mitochondria are the main site of aerobic respiration, where energy is released from food molecules." },
  { subject: "Mathematics", q: "Solve for x: 3x + 7 = 22.", options: ["3", "5", "7", "9"], answer: 1, explain: "Subtract 7 from both sides: 3x = 15. Divide both sides by 3, so x = 5." },
  { subject: "English Language", q: "Choose the word nearest in meaning to 'diligent'.", options: ["Careless", "Hardworking", "Impatient", "Uncertain"], answer: 1, explain: "Diligent means showing care and steady effort in one's work; hardworking is the closest option." }
];

type Msg = { role: "user" | "assistant"; text: string };
type Question = (typeof questions)[number];

const events = [
  { type: "SCHOLARSHIP", title: "Undergraduate scholarship opportunities", date: "Explore opportunities", tone: "purple" },
  { type: "EXAM UPDATE", title: "Build your weekly revision plan", date: "Study planning", tone: "blue" },
  { type: "STUDENT LIFE", title: "Find a study partner in your subject", date: "Community", tone: "green" }
];

function Dashboard() {
  const { user, profile } = useAuth();
  const [active, setActive] = useState<Section>("Overview");
  const [mobileNav, setMobileNav] = useState(false);
  const [query, setQuery] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const toastTimer = useRef<number | null>(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [exam, setExam] = useState("JAMB");
  const [qIndex, setQIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<Msg[]>([
    { role: "assistant", text: "Hi! I'm Brotherly, your study companion. Ask me to explain a topic, help you plan revision, or practise a question. I can explain topics, help you revise, and work through exam questions with you." }
  ]);
  const [toast, setToast] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);

  const filteredSubjects = useMemo(() => subjects.filter(s => s.name.toLowerCase().includes(searchQuery.toLowerCase())), [searchQuery]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setSearchOpen(o => !o); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => () => { if (toastTimer.current) window.clearTimeout(toastTimer.current); }, []);
  const currentQuestion = questions[qIndex % questions.length];

  function notify(message: string) {
    setToast(message);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 2800);
  }

  function navigate(section: Section) {
    setActive(section);
    setMobileNav(false);
    setQuery("");
  }

  async function sendChat() {
    const value = chatInput.trim();
    if (!value || chatLoading) return;
    const history: Msg[] = [...chatMessages, { role: "user", text: value }];
    setChatMessages([...history, { role: "assistant", text: "Thinking..." }]);
    setChatInput("");
    setChatLoading(true);
    let reply = "Brotherly couldn't reach the server. Check your connection and try again.";
    try {
      await auth.currentUser?.reload();
      const token = await auth.currentUser?.getIdToken(true);
      if (!token) throw new Error("Please sign in again to use Brotherly.");
      const res = await fetch("/api/tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
        body: JSON.stringify({ messages: history })
      });
      const data = await res.json();
      reply = data.reply ?? data.error ?? reply;
    } catch {}
    setChatMessages(prev => [...prev.slice(0, -1), { role: "assistant", text: reply }]);
    setChatLoading(false);
  }

  return (
    <main className="app-shell">
      {mobileNav && <button className="mobile-scrim" aria-label="Close menu" onClick={() => setMobileNav(false)} />}
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><span>B</span><i>+</i></div>
          <div><div className="brand-name">brotherlly<span>.</span></div><div className="brand-caption">LEARN • PRACTISE • GROW</div></div>
          <button className="icon-btn sidebar-close" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={18}/></button>
        </div>
        <div className="workspace-chip"><div className="workspace-avatar">S</div><div className="workspace-copy"><strong>Student space</strong><small>Your learning hub</small></div><ChevronDown size={15}/></div>
        <nav className="nav-list">
          {navGroups.map(group => <div className="nav-group" key={group.title}>
            <p className="nav-label">{group.title}</p>
            {group.items.map(item => {
              const Icon = item.icon;
              return <button key={item.label} className={`nav-item ${active === item.label ? "active" : ""}`} onClick={() => navigate(item.label)}>
                <Icon size={18} strokeWidth={1.8}/><span>{item.label}</span>{item.tag && <em>{item.tag}</em>}
              </button>;
            })}
          </div>)}
        </nav>
        <div className="sidebar-bottom">
          <div className="upgrade-card"><div className="upgrade-icon"><Sparkles size={17}/></div><strong>Make learning count.</strong><p>Build a steady study habit, one session at a time.</p><button onClick={() => notify("Premium subscriptions will be connected after payment verification is implemented.")}>Explore Premium <ArrowRight size={14}/></button></div>
          <button className="nav-item help-item" onClick={() => notify("Help centre is coming soon.")}><CircleHelp size={18}/><span>Help & support</span></button>
          <div className="sidebar-footer"><span className="status-dot"/> Preview environment <span className="version">v1.0</span></div>
        </div>
      </aside>

      <section className="main-area">
        <header className="topbar">
          <button className="icon-btn mobile-menu" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu size={21}/></button>
          <div className="breadcrumb"><span>Workspace</span><ChevronRight size={14}/><strong>{active}</strong></div>
          <div className="top-actions">
            <button className={`search-trigger ${searchOpen ? "search-active" : ""}`} onClick={() => setSearchOpen(!searchOpen)}><Search size={16}/><span>Search anything...</span><kbd>⌘ K</kbd></button>
            {searchOpen && <div className="search-popover"><label>Search study subjects</label><input autoFocus value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Try Mathematics..." />{filteredSubjects.map(s => <button key={s.code} onClick={() => { setActive("Study Notes"); setQuery(s.name); setSearchQuery(""); setSearchOpen(false); }}>{s.name}<ArrowRight size={14}/></button>)}{filteredSubjects.length === 0 && <small>No subjects found.</small>}</div>}
            <div className="top-action-wrap"><button className="icon-btn notification-btn" onClick={() => setShowNotifications(!showNotifications)} aria-label="Notifications"><Bell size={18}/><i/></button>{showNotifications && <div className="popover"><strong>You&apos;re all caught up</strong><p>Study reminders and updates will appear here.</p></div>}</div>
            <div className="top-action-wrap"><button className="user-pill" onClick={() => setShowProfile(!showProfile)}><div className="user-avatar">{(profile?.name || user?.email || "S").slice(0,1).toUpperCase()}</div><span><strong>{profile?.name || "Learner"}</strong><small>{profile?.role === "tutor" ? "Tutor account" : "Student account"}</small></span><ChevronDown size={14}/></button>{showProfile && <div className="popover profile-popover"><strong>{profile?.name || "My profile"}</strong><p>{user?.email} · {profile?.role || "learner"}</p><button onClick={async () => { const { signOut } = await import("firebase/auth"); await signOut(auth); }}>Sign out</button><button onClick={() => { navigate("My Profile"); setShowProfile(false); }}>View profile <ArrowRight size={14}/></button></div>}</div>
          </div>
        </header>

        <div className="page-content">
          {active === "Tutors" && <TutorsDirectory notify={notify} />}
          {active === "Overview" && <Overview navigate={navigate} notify={notify} />}
          {active === "Exam Centre" && <ExamCentre exam={exam} setExam={setExam} navigate={navigate} />}
          {active === "CBT Practice" && <CBT currentQuestion={currentQuestion} qIndex={qIndex} setQIndex={setQIndex} selected={selected} setSelected={setSelected} showAnswer={showAnswer} setShowAnswer={setShowAnswer}/>}
          {active === "Study Notes" && <StudyNotes query={query} setQuery={setQuery} />}
          {active === "Brotherly" && <Brotherly messages={chatMessages} input={chatInput} setInput={setChatInput} send={sendChat}/>}
          {active === "Schools & Campus" && <GenericPage icon={<MapPin size={23}/>} eyebrow="CAMPUS DIRECTORY" title="Find your next study space." desc="Explore schools, campus resources and student-friendly places. Live maps and verified listings will be connected in a later phase." cards={[["School directory","Browse institutions and useful campus details."],["Campus resources","Discover libraries, reading spaces and student services."],["Map view","Location-based results require map configuration."]]} />}
          {active === "Community" && <GenericPage icon={<Users size={23}/>} eyebrow="STUDENT COMMUNITY" title="Learn better, together." desc="A space for study groups, thoughtful discussions and sharing learning resources." cards={[["Study groups","Create or join a subject-based study group."],["Discussion board","Ask questions and share what you've learned."],["Community guidelines","Respectful, moderated student spaces."]]} />}
          {active === "Events & Opportunities" && <EventsPage />}
          {active === "Marketplace" && <GenericPage icon={<ShoppingBag size={23}/>} eyebrow="STUDENT MARKETPLACE" title="Useful things, student to student." desc="A future marketplace for books, learning supplies and student services. Listings and safe transaction workflows are not live in this preview." cards={[["Books & materials","Find study materials and textbooks."],["Student services","Discover useful services from other students."],["Safety first","Verified accounts and reporting will be required before launch."]]} />}
          {active === "My Profile" && <ProfilePage notify={notify}/>}
          <footer className="page-footer"><span>© 2026 Brotherlly Hub</span><span><i className="status-dot"/> Built for curious minds</span><button onClick={() => notify("Help centre is coming soon.")}>Help centre</button><span className="footer-note">Preview build · Demo content</span></footer>
        </div>
      </section>
      {toast && <div className="toast"><Check size={16}/>{toast}</div>}
    </main>
  );
}

function PageHeading({ eyebrow, title, desc, action }: { eyebrow: string; title: string; desc: string; action?: React.ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{desc}</p></div>{action}</div>;
}

function Overview({ navigate, notify }: { navigate: (s: Section) => void; notify: (s: string) => void }) {
  return <>
    <div className="welcome-banner"><div className="welcome-content"><div className="welcome-label"><span className="welcome-spark">✳</span> YOUR LEARNING SPACE</div><h1>A little progress,<br/><span>every single day.</span></h1><p>Build your confidence, sharpen your skills, and prepare for what comes next.</p><div className="welcome-actions"><button className="btn-primary" onClick={() => navigate("CBT Practice")}>Start practising <ArrowRight size={16}/></button><button className="btn-quiet" onClick={() => navigate("Exam Centre")}>Explore exams <ChevronRight size={16}/></button></div></div><div className="hero-art" aria-hidden="true"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="hero-glow"/><div className="hero-book"><BookOpen size={54} strokeWidth={1.25}/></div><div className="float-card float-card-top"><span className="float-icon purple"><Target size={15}/></span><span><strong>Stay curious</strong><small>One topic at a time</small></span></div><div className="float-card float-card-bottom"><span className="float-icon green"><Zap size={15}/></span><span><strong>Keep your streak</strong><small>Consistency wins</small></span></div><div className="hero-star star-a">✦</div><div className="hero-star star-b">✧</div></div><div className="banner-decoration">B.</div></div>
    <div className="section-title-row"><div><h2>Your learning snapshot</h2><p>A quick look at your study space.</p></div><span className="demo-label"><span/> SAMPLE DATA</span></div>
    <div className="stats-grid">
      <StatCard icon={<BookOpen size={18}/>} tone="blue" label="Questions practised" value="128" change="Sample metric" foot="Across all subjects"/>
      <StatCard icon={<Target size={18}/>} tone="purple" label="Average accuracy" value="76%" change="Sample metric" foot="Keep building confidence"/>
      <StatCard icon={<Activity size={18}/>} tone="green" label="Study streak" value="4 days" change="Sample metric" foot="Small steps add up"/>
      <StatCard icon={<Trophy size={18}/>} tone="orange" label="Topics explored" value="12" change="Sample metric" foot="Keep exploring"/>
    </div>
    <div className="dashboard-grid">
      <section className="panel subjects-panel"><div className="panel-heading"><div><h3>Pick up where you left off</h3><p>Sample subject progress</p></div><button className="text-link" onClick={() => navigate("Study Notes")}>All subjects <ArrowRight size={14}/></button></div><div className="subject-list">{subjects.map(s => <button className="subject-row" key={s.code} onClick={() => navigate("Study Notes")}><div className={`subject-icon ${s.color}`}>{s.icon}</div><div className="subject-main"><div className="subject-name-row"><strong>{s.name}</strong><span>{s.progress}%</span></div><div className="progress-track"><div className={`progress-fill ${s.color}`} style={{width: `${s.progress}%`}}/></div><small>{s.progress > 70 ? "Looking good — keep it up" : s.progress > 40 ? "You're making progress" : "A good place to focus next"}</small></div><ChevronRight className="subject-chevron" size={16}/></button>)}</div><button className="wide-outline" onClick={() => navigate("Study Notes")}>Explore study notes <ArrowRight size={15}/></button></section>
      <section className="panel quick-panel"><div className="panel-heading"><div><h3>Quick start</h3><p>Choose your next step</p></div><span className="tiny-spark">✳</span></div><div className="quick-list"><QuickAction icon={<GraduationCap size={19}/>} tone="purple" title="Prepare for an exam" desc="Choose JAMB, WAEC or NECO" onClick={() => navigate("Exam Centre")}/><QuickAction icon={<Target size={19}/>} tone="blue" title="Try a CBT session" desc="Practise with sample questions" onClick={() => navigate("CBT Practice")}/><QuickAction icon={<BrainCircuit size={19}/>} tone="green" title="Ask Brotherly" desc="Explore the study assistant" onClick={() => navigate("Brotherly")}/><QuickAction icon={<Users size={19}/>} tone="orange" title="Find your community" desc="Discover study groups" onClick={() => navigate("Community")}/></div></section>
    </div>
    <div className="section-title-row opportunities-title"><div><h2>Things worth exploring</h2><p>Find useful next steps beyond your notes.</p></div><button className="text-link" onClick={() => navigate("Events & Opportunities")}>View all <ArrowRight size={14}/></button></div>
    <div className="event-grid">{events.map((e,i) => <button className="event-card" key={e.title} onClick={() => navigate(i===2 ? "Community" : "Events & Opportunities")}><div className={`event-illustration ${e.tone}`}><span>{i===0 ? "✦" : i===1 ? "↗" : "◎"}</span><div className="event-shape"/></div><div className="event-copy"><span className={`event-type ${e.tone}`}>{e.type}</span><h3>{e.title}</h3><div className="event-meta">{e.date}<ArrowUpRight size={14}/></div></div></button>)}</div>
    <div className="bottom-tip"><div className="tip-icon"><Sparkles size={18}/></div><div><strong>Small, consistent effort goes a long way.</strong><p>Try setting aside 20 minutes today for one topic you want to understand better.</p></div><button onClick={() => notify("Study reminders will be available after accounts are connected.")}>Set a reminder <ArrowRight size={14}/></button></div>
  </>;
}

function StatCard({ icon, tone, label, value, change, foot }: { icon: React.ReactNode; tone: string; label: string; value: string; change: string; foot: string }) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-change">{change}</div><div className="stat-foot">{foot}</div></div>;
}

function QuickAction({ icon, tone, title, desc, onClick }: { icon: React.ReactNode; tone: string; title: string; desc: string; onClick: () => void }) {
  return <button className="quick-action" onClick={onClick}><span className={`quick-icon ${tone}`}>{icon}</span><span className="quick-copy"><strong>{title}</strong><small>{desc}</small></span><ArrowUpRight size={16} className="quick-arrow"/></button>;
}

function ExamCentre({ exam, setExam, navigate }: { exam: string; setExam: (v:string)=>void; navigate:(s:Section)=>void }) {
  const exams = [
    { name: "JAMB UTME", short: "JAMB", desc: "Prepare for university entrance", subjects: "4 subjects", color: "purple", icon: "J" },
    { name: "WAEC", short: "WAEC", desc: "Senior secondary certificate prep", subjects: "Core & electives", color: "blue", icon: "W" },
    { name: "NECO", short: "NECO", desc: "National examinations practice", subjects: "Core & electives", color: "green", icon: "N" },
    { name: "JSSCE", short: "JSSCE", desc: "Junior secondary revision", subjects: "Multiple subjects", color: "orange", icon: "J" }
  ];
  return <><PageHeading eyebrow="EXAM CENTRE" title="Your next result starts here." desc="Choose an exam pathway and build a study routine that works for you."/><div className="exam-feature"><div><span className="feature-kicker"><GraduationCap size={15}/> EXAM PREPARATION</span><h2>Prepare with purpose.</h2><p>Practise topics, review explanations and build confidence one question at a time.</p><button className="btn-primary" onClick={() => navigate("CBT Practice")}>Try sample CBT <ArrowRight size={15}/></button></div><div className="exam-feature-art"><div className="paper paper-back"/><div className="paper"><span>EXAM</span><i/><i/><i/><i/><b>✓</b></div><div className="feature-badge"><Check size={14}/> Keep learning</div></div></div><div className="section-title-row"><div><h2>Choose your examination</h2><p>Question bank content will be added from verified, authorised sources.</p></div></div><div className="exam-grid">{exams.map(e=><button key={e.short} className={`exam-card ${exam===e.short?"exam-selected":""}`} onClick={()=>setExam(e.short)}><div className={`exam-emblem ${e.color}`}>{e.icon}</div><div className="exam-card-title"><h3>{e.name}</h3>{exam===e.short && <span><Check size={13}/></span>}</div><p>{e.desc}</p><div className="exam-card-bottom"><small>{e.subjects}</small><ArrowRight size={15}/></div></button>)}</div><div className="notice-box"><ShieldCheck size={20}/><div><strong>Study with reliable material</strong><p>This starter contains sample questions only. It does not claim to be an official or complete past-question archive.</p></div></div></>;
}

function CBT({ currentQuestion, qIndex, setQIndex, selected, setSelected, showAnswer, setShowAnswer }: {
  currentQuestion: Question; qIndex: number; setQIndex: (n: number) => void;
  selected: number | null; setSelected: (n: number | null) => void;
  showAnswer: boolean; setShowAnswer: (b: boolean) => void;
}) {
  return <><PageHeading eyebrow="CBT PRACTICE" title="Practise. Review. Improve." desc="Try this short sample session. Your results are not saved in this preview." action={<span className="session-chip"><Clock3 size={14}/> Practice mode</span>}/><div className="cbt-layout"><div className="panel cbt-main"><div className="cbt-toolbar"><div><span className="cbt-label">SAMPLE QUESTION</span><h3>{currentQuestion.subject} <span>·</span> Practice</h3></div><span className="question-count">Question {(qIndex%questions.length)+1} of {questions.length}</span></div><div className="cbt-progress"><span style={{width:`${(((qIndex%questions.length)+1)/questions.length)*100}%`}}/></div><div className="question-body"><div className="question-number">QUESTION {(qIndex%questions.length)+1}</div><h2>{currentQuestion.q}</h2><div className="answer-options">{currentQuestion.options.map((o,i)=><button key={o} className={`answer-option ${selected===i?"option-selected":""} ${showAnswer&&i===currentQuestion.answer?"option-correct":""} ${showAnswer&&selected===i&&i!==currentQuestion.answer?"option-wrong":""}`} onClick={()=>{setSelected(i);setShowAnswer(false)}}><span className="option-letter">{String.fromCharCode(65+i)}</span><span>{o}</span>{showAnswer&&i===currentQuestion.answer&&<Check size={17}/>}</button>)}</div>{showAnswer&&<div className="explanation-box"><strong>{selected===currentQuestion.answer?"Correct answer!":"Let's review this one."}</strong><p>{currentQuestion.explain}</p></div>}<div className="question-actions"><span className="sample-disclaimer">Sample content · Not an official past question</span>{!showAnswer?<button className="btn-primary" disabled={selected===null} onClick={()=>setShowAnswer(true)}>Check answer <ArrowRight size={15}/></button>:<button className="btn-primary" onClick={()=>{setQIndex((qIndex+1)%questions.length);setSelected(null);setShowAnswer(false)}}>Next question <ArrowRight size={15}/></button>}</div></div></div><aside className="panel cbt-side"><div className="side-icon"><Target size={21}/></div><h3>Practice at your pace</h3><p>Use sample questions to get familiar with the CBT flow.</p><div className="cbt-side-stat"><span>Question type</span><strong>Multiple choice</strong></div><div className="cbt-side-stat"><span>Answer review</span><strong>Instant feedback</strong></div><div className="cbt-side-stat"><span>Saved results</span><strong>Not connected</strong></div><div className="notice-small"><CircleHelp size={16}/><span>Progress tracking will be enabled when student accounts and the database are connected.</span></div></aside></div></>;
}

function StudyNotes({ query, setQuery }: { query:string; setQuery:(v:string)=>void }) {
  const [filter,setFilter] = useState("All subjects");
  const notes = [
    {subject:"Mathematics",level:"SS1–SS3",title:"Algebra: expressions and equations",desc:"Revise core algebra concepts and practise solving linear equations.",tag:"Mathematics",tone:"violet",icon:"∑"},
    {subject:"English Language",level:"SS1–SS3",title:"Parts of speech and sentence structure",desc:"Understand nouns, verbs, clauses and how sentences work.",tag:"English",tone:"blue",icon:"Aa"},
    {subject:"Biology",level:"SS1–SS3",title:"Cell structure and organisation",desc:"Explore cell organelles and the functions they perform.",tag:"Biology",tone:"green",icon:"⌁"},
    {subject:"Chemistry",level:"SS1–SS3",title:"Atoms, elements and compounds",desc:"Build a foundation in atomic structure and chemical substances.",tag:"Chemistry",tone:"orange",icon:"⚗"},
    {subject:"Physics",level:"SS1–SS3",title:"Motion, speed and acceleration",desc:"Review motion and practise using the key equations.",tag:"Physics",tone:"blue",icon:"↗"},
    {subject:"Mathematics",level:"SS1–SS3",title:"Indices and logarithms",desc:"Learn the laws of indices and introductory logarithms.",tag:"Mathematics",tone:"violet",icon:"x²"}
  ];
  const shown = notes.filter(n=>(filter==="All subjects"||n.subject===filter)&&`${n.title} ${n.desc} ${n.subject}`.toLowerCase().includes(query.toLowerCase()));
  return <><PageHeading eyebrow="STUDY NOTES" title="Make the hard things clearer." desc="Explore starter study topics and build a foundation for your next revision session."/><div className="notes-toolbar"><div className="notes-search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search notes and topics..."/></div><select value={filter} onChange={e=>setFilter(e.target.value)} aria-label="Filter by subject"><option>All subjects</option>{subjects.map(s=><option key={s.code}>{s.name}</option>)}<option>Physics</option></select></div><div className="notes-grid">{shown.map(n=><article className="note-card" key={n.title}><div className={`note-icon ${n.tone}`}>{n.icon}</div><div className="note-meta"><span>{n.tag}</span><span>{n.level}</span></div><h3>{n.title}</h3><p>{n.desc}</p><button onClick={()=>alert("This is a starter topic card. Full lesson content will be added in the content phase.")}>Open topic <ArrowRight size={14}/></button></article>)}</div>{shown.length===0&&<div className="empty-state">No matching topics. Try another search.</div>}<div className="notice-box"><BookOpen size={20}/><div><strong>Content note</strong><p>These are starter topic cards, not a complete textbook or verified exam syllabus. Full lesson content will be developed separately.</p></div></div></>;
}

function Brotherly({ messages, input, setInput, send }: { messages: Msg[]; input: string; setInput: (v: string) => void; send: () => void }) {
  const [voiceListening,setVoiceListening]=useState(false);
  function startVoice() {
    const w=window as unknown as {SpeechRecognition?:new()=>any;webkitSpeechRecognition?:new()=>any};
    const Recognition=w.SpeechRecognition||w.webkitSpeechRecognition;
    if(!Recognition){alert("Voice input is not supported in this browser. Try Chrome on Android.");return;}
    const recognition=new Recognition();
    recognition.lang="en-NG"; recognition.interimResults=false; recognition.maxAlternatives=1;
    recognition.onresult=(event:any)=>{setInput(event.results?.[0]?.[0]?.transcript||"");setVoiceListening(false);};
    recognition.onerror=()=>setVoiceListening(false); recognition.onend=()=>setVoiceListening(false);
    setVoiceListening(true); recognition.start();
  }
  function speak(text:string) {
    if(!("speechSynthesis" in window)){alert("Speech playback is not supported in this browser.");return;}
    window.speechSynthesis.cancel();
    const utterance=new SpeechSynthesisUtterance(text); utterance.lang="en-NG"; utterance.rate=0.95;
    window.speechSynthesis.speak(utterance);
  }
  return <><PageHeading eyebrow="YOUR STUDY COMPANION" title="Meet Brotherly." desc="A calmer space to ask questions, explore ideas and plan your learning."/><div className="tutor-layout"><div className="tutor-welcome"><div className="tutor-orb"><BrainCircuit size={34}/><span/></div><span className="feature-kicker"><Sparkles size={14}/> STUDY ASSISTANT</span><h2>Let&apos;s figure it out<br/>together.</h2><p>Ask a question, break down a difficult topic or plan your next revision session.</p><div className="prompt-chips"><button onClick={()=>setInput("Explain photosynthesis in simple terms.")}>Explain a topic <ArrowUpRight size={13}/></button><button onClick={()=>setInput("Help me create a weekly revision plan.")}>Plan my revision <ArrowUpRight size={13}/></button><button onClick={()=>setInput("Give me a practice question on algebra.")}>Practise a question <ArrowUpRight size={13}/></button></div></div><div className="panel chat-panel"><div className="chat-head"><div className="chat-avatar"><BrainCircuit size={18}/></div><div><strong>Brotherly</strong><small><span className="status-dot"/> Live tutor</small></div><span className="chat-beta">BETA</span></div><div className="chat-messages">{messages.map((m,i)=><div key={i} className={`chat-message ${m.role}`}><div className="message-avatar">{m.role==="assistant"?<BrainCircuit size={15}/>: "S"}</div><div className="message-bubble">{m.text}{m.role==="assistant"&&i>0&&<button className="speak-answer" type="button" onClick={()=>speak(m.text)} aria-label="Read answer aloud"><Volume2 size={13}/> Listen</button>}</div></div>)}</div><form className="chat-input-row" onSubmit={e=>{e.preventDefault();send()}}><input value={input} onChange={e=>setInput(e.target.value)} placeholder="Ask Brotherly something..." aria-label="Message Brotherly"/><button className="voice-input" type="button" onClick={startVoice} aria-label="Speak your question" title={voiceListening?"Listening…":"Speak your question"}><Mic size={17}/></button><button type="submit" aria-label="Send message" disabled={!input.trim()}><ArrowRight size={17}/></button></form><div className="chat-privacy"><ShieldCheck size={13}/> Voice input and read-aloud use your browser. Don&apos;t share passwords or sensitive personal information.</div></div></div><div className="notice-box"><CircleHelp size={20}/><div><strong>Study safely with Brotherly</strong><p>Your messages are sent to the configured Gemini model through a protected server endpoint. Do not share passwords, personal identifiers, or sensitive information.</p></div></div></>;
}

function EventsPage() {
  return <><PageHeading eyebrow="EVENTS & OPPORTUNITIES" title="Keep an eye on what's next." desc="A place for scholarships, student events and useful opportunities. Listings below are examples, not verified active offers."/><div className="event-list">{events.map((e,i)=><div className="opportunity-row" key={e.title}><div className={`opportunity-icon ${e.tone}`}>{i===0?<Trophy size={21}/>:i===1?<CalendarDays size={21}/>:<Users size={21}/>}</div><div className="opportunity-copy"><span className={`event-type ${e.tone}`}>{e.type}</span><h3>{e.title}</h3><p>{e.date}</p></div><button className="icon-btn" aria-label={`Learn about ${e.title}`} onClick={()=>alert("Verified live listings will be added in a later phase.")}><ArrowUpRight size={18}/></button></div>)}</div><div className="notice-box"><ShieldCheck size={20}/><div><strong>Verify before you apply</strong><p>Always check scholarship and event details on the organiser&apos;s official website. This preview does not contain verified live opportunities.</p></div></div></>;
}

function ProfilePage({notify}:{notify:(s:string)=>void}) {
  return <><PageHeading eyebrow="MY PROFILE" title="Your learning journey." desc="Your profile and study progress will live here once accounts are connected."/><div className="panel profile-card"><div className="profile-cover"><div className="profile-big-avatar">S</div></div><div className="profile-details"><div><h2>Student</h2><p>Brotherlly Hub learner · Preview account</p></div><button className="btn-secondary" onClick={()=>notify("Profile editing requires account authentication.")}>Edit profile <Settings size={15}/></button></div><div className="profile-stat-grid"><div><strong>—</strong><span>Study sessions</span></div><div><strong>—</strong><span>Questions answered</span></div><div><strong>—</strong><span>Current streak</span></div></div></div><div className="notice-box"><ShieldCheck size={20}/><div><strong>Preview profile</strong><p>This is not a real signed-in account. Authentication and personal data storage have not been configured.</p></div></div></>;
}

function GenericPage({icon,eyebrow,title,desc,cards}:{icon:React.ReactNode;eyebrow:string;title:string;desc:string;cards:[string,string][]}) {
  return <><PageHeading eyebrow={eyebrow} title={title} desc={desc}/><div className="generic-hero"><div className="generic-icon">{icon}</div><div><span className="feature-kicker"><Compass size={14}/> COMING TO BROTHERLLY</span><h2>A useful space, built around students.</h2><p>We are laying the groundwork for a reliable experience. This section is a preview of planned features, not a live service yet.</p></div></div><div className="generic-card-grid">{cards.map((c,i)=><div className="generic-card" key={c[0]}><div className="generic-card-number">0{i+1}</div><h3>{c[0]}</h3><p>{c[1]}</p><span className="planned-pill"><span/> Planned feature</span></div>)}</div></>;
}

export default function Home() {
  return <AuthGate><Dashboard /></AuthGate>;
}
