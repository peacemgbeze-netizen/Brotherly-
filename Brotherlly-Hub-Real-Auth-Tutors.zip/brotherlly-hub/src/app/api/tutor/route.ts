import { NextResponse } from "next/server";
import { cert, getApps, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";

export const runtime = "nodejs";
type Msg = { role: "user" | "assistant"; text: string };
const SYSTEM_PROMPT = `You are Brotherly, a careful study tutor for Nigerian secondary-school students preparing for JAMB, WAEC, NECO and JSSCE.
Use clear, age-appropriate English and short steps. Teach the concept, then give a worked example or a quick check question. For calculations, show every step. Never invent past-question years, question numbers, official cut-offs, or sources. If unsure, say so. Do not ask for passwords, payment card data, or other secrets.`;
const hits = new Map<string, number[]>();
function limited(uid:string) {
  const now=Date.now();
  const recent=(hits.get(uid)??[]).filter(t=>now-t<10*60_000);
  recent.push(now); hits.set(uid,recent);
  return recent.length>25;
}
function adminAuth() {
  const raw=process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if(!raw) throw new Error("Firebase Admin is not configured.");
  const serviceAccount=JSON.parse(raw);
  const app=getApps()[0]??initializeApp({credential:cert(serviceAccount)});
  return getAuth(app);
}
export async function POST(req:Request) {
  if(!process.env.GEMINI_API_KEY) return NextResponse.json({error:"Brotherly AI is not configured yet."},{status:503});
  let decoded;
  try {
    const authHeader=req.headers.get("authorization")||"";
    if(!authHeader.startsWith("Bearer ")) return NextResponse.json({error:"Sign in to use Brotherly."},{status:401});
    decoded=await adminAuth().verifyIdToken(authHeader.slice(7),true);
    if(!decoded.email_verified) return NextResponse.json({error:"Verify your email before using the tutor."},{status:403});
  } catch {
    return NextResponse.json({error:"Your session could not be verified. Sign in again."},{status:401});
  }
  if(limited(decoded.uid)) return NextResponse.json({error:"You have reached the short-term tutor limit. Try again in a few minutes."},{status:429});
  let body:{messages?:Msg[]};
  try { body=await req.json(); } catch { return NextResponse.json({error:"Invalid request."},{status:400}); }
  if(!Array.isArray(body.messages)||body.messages.length>20) return NextResponse.json({error:"Invalid conversation history."},{status:400});
  const history=body.messages.filter(m=>(m?.role==="user"||m?.role==="assistant")&&typeof m.text==="string"&&m.text.trim()).slice(-10).map(m=>({role:m.role==="user"?"user":"model",parts:[{text:m.text.trim().slice(0,2000)}]}));
  while(history.length&&history[0].role!=="user") history.shift();
  if(!history.length||history[history.length-1].role!=="user") return NextResponse.json({error:"Send a question first."},{status:400});
  const model=process.env.GEMINI_MODEL||"gemini-2.5-flash";
  try {
    const res=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{
      method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":process.env.GEMINI_API_KEY!},
      body:JSON.stringify({systemInstruction:{parts:[{text:SYSTEM_PROMPT}]},contents:history,generationConfig:{maxOutputTokens:900,temperature:0.35}}),
      signal:AbortSignal.timeout(25000)
    });
    if(!res.ok){console.error("Gemini request failed with status",res.status);return NextResponse.json({error:"Brotherly is temporarily unavailable. Please try again."},{status:502});}
    const data=await res.json();
    const reply:string|undefined=data?.candidates?.[0]?.content?.parts?.map((p:{text?:string})=>p.text??"").join("").trim();
    if(!reply)return NextResponse.json({error:"No answer returned. Try rephrasing your question."},{status:502});
    return NextResponse.json({reply},{headers:{"Cache-Control":"no-store"}});
  } catch { return NextResponse.json({error:"The tutor request timed out. Check your connection and try again."},{status:502});}
}
