import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Brotherlly Hub — Learn. Practise. Grow.",
  description: "Your learning space for JAMB, WAEC, NECO and JSSCE preparation.",
  applicationName: "Brotherlly Hub"
};

export const viewport: Viewport = {
  themeColor: "#0b1020",
  width: "device-width",
  initialScale: 1
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
