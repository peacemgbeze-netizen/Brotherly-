 "use client";
import { createContext, useContext, useEffect, useState } from "react";
import type { User } from "firebase/auth";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db, firebaseConfigured } from "./firebase";

export type UserRole = "student" | "tutor";
export type UserProfile = { uid: string; name: string; email?: string; role: UserRole; bio?: string; subjects?: string[]; tutorApproved?: boolean; createdAt?: unknown };
type AuthContextValue = { user: User | null; profile: UserProfile | null; loading: boolean; refreshProfile: () => Promise<void> };
const AuthContext = createContext<AuthContextValue>({ user: null, profile: null, loading: true, refreshProfile: async () => {} });
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user,setUser] = useState<User|null>(null);
  const [profile,setProfile] = useState<UserProfile|null>(null);
  const [loading,setLoading] = useState(true);
  const refreshProfile = async () => {
    if (!auth.currentUser || !firebaseConfigured) { setProfile(null); return; }
    const snap = await getDoc(doc(db,"profiles",auth.currentUser.uid));
    setProfile(snap.exists() ? snap.data() as UserProfile : null);
  };
  useEffect(() => {
    if (!firebaseConfigured) { setLoading(false); return; }
    return onAuthStateChanged(auth, async (next) => {
      setUser(next);
      if (next) {
        try {
          const snap = await getDoc(doc(db,"profiles",next.uid));
          setProfile(snap.exists() ? snap.data() as UserProfile : null);
        } catch { setProfile(null); }
      } else setProfile(null);
      setLoading(false);
    });
  },[]);
  return <AuthContext.Provider value={{user,profile,loading,refreshProfile}}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
