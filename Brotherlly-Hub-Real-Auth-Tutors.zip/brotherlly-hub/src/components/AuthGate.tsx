 "use client";
import { FormEvent, useState } from "react";
import { createUserWithEmailAndPassword, sendPasswordResetEmail, sendEmailVerification, signInWithEmailAndPassword, updateProfile, signOut } from "firebase/auth";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db, firebaseConfigured } from "../lib/firebase";
import { AuthProvider, useAuth, UserRole } from "../lib/auth-context";
import { BookOpen, Eye, EyeOff, GraduationCap, ShieldCheck, Users } from "lucide-react";

function AuthScreen() {
  const { user, profile, loading, refreshProfile } = useAuth();
  const [mode,setMode] = useState<"login"|"signup"|"reset">("login");
  const [name,setName] = useState("");
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [role,setRole] = useState<UserRole>("student");
  const [showPassword,setShowPassword] = useState(false);
  const [busy,setBusy] = useState(false);
  const [message,setMessage] = useState("");
  const [error,setError] = useState("");
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError(""); setMessage("");
    try {
      if (mode === "reset") {
        await sendPasswordResetEmail(auth,email.trim());
        setMessage("If an account exists for that email, a password-reset link has been sent. Check your inbox and spam folder.");
      } else if (mode === "login") {
        await signInWithEmailAndPassword(auth,email.trim(),password);
      } else {
        if (name.trim().length < 2) throw new Error("Enter your name.");
        if (password.length < 8) throw new Error("Use a password with at least 8 characters.");
        const cred = await createUserWithEmailAndPassword(auth,email.trim(),password);
        await updateProfile(cred.user,{displayName:name.trim()});
        await setDoc(doc(db,"profiles",cred.user.uid),{
          uid:cred.user.uid,name:name.trim(),role,tutorApproved:false,
          bio:"",subjects:[],createdAt:serverTimestamp(),emailVerified:false
        });
        await sendEmailVerification(cred.user);
        await refreshProfile();
        setMessage("Account created. A verification email has been sent. Verify your email before offering tutoring or requesting a session.");
      }
    } catch (e) {
      const code = (e as {code?:string}).code;
      if (mode === "reset") {
        setMessage("If an account exists for that email, a password-reset link has been sent. Check your inbox and spam folder.");
        setBusy(false);
        return;
      }
      const friendly: Record<string,string> = {
        "auth/invalid-credential":"Email or password is incorrect.",
        "auth/email-already-in-use":"An account already uses this email. Try signing in.",
        "auth/invalid-email":"Enter a valid email address.",
        "auth/weak-password":"Choose a stronger password (at least 8 characters).",
        "auth/too-many-requests":"Too many attempts. Wait a while and try again.",
        "auth/network-request-failed":"Network error. Check your connection."
      };
      setError(friendly[code ?? ""] ?? (e instanceof Error ? e.message : "Something went wrong. Try again."));
    } finally { setBusy(false); }
  }
  if (!firebaseConfigured) return <main className="auth-page"><section className="auth-card setup-card"><div className="auth-logo">B+</div><p className="auth-eyebrow">BROTHERLLY HUB SETUP</p><h1>Connect your Firebase project</h1><p>Authentication is real, but it needs your Firebase web configuration before anyone can sign in.</p><ol><li>Create or open a project in Firebase Console.</li><li>Enable <b>Authentication → Email/Password</b>.</li><li>Create a Firestore database.</li><li>Copy the values into <code>.env.local</code> using the supplied <code>.env.example</code>.</li></ol><p className="auth-note">Never place your Gemini or Firebase Admin secret keys in client-side variables.</p></section></main>;
  if (loading) return <main className="auth-page"><div className="auth-card">Loading your secure student space…</div></main>;
  if (user && profile) return <>{/* dashboard follows */}</>;
  if (user && !profile) return <main className="auth-page"><section className="auth-card"><h1>Finishing your profile</h1><p>Your account exists, but its profile could not be loaded. Refresh the page or contact support.</p><button className="auth-submit" onClick={()=>window.location.reload()}>Retry profile</button><button className="auth-link" onClick={()=>signOut(auth)}>Sign out</button></section></main>;
  return <main className="auth-page"><section className="auth-card">
    <div className="auth-logo">B+</div><p className="auth-eyebrow">LEARN · PRACTISE · GROW</p>
    <h1>{mode==="login"?"Welcome back.":mode==="signup"?"Create your learning account.":"Reset your password."}</h1>
    <p className="auth-subtitle">{mode==="login"?"Sign in to continue your learning journey.":mode==="signup"?"Join students and tutors on Brotherlly Hub.":"We’ll send a secure reset link to your email."}</p>
    {error && <div className="auth-error" role="alert">{error}</div>}{message && <div className="auth-success" role="status">{message}</div>}
    <form onSubmit={submit}>
      {mode==="signup" && <label>Full name<input value={name} onChange={e=>setName(e.target.value)} autoComplete="name" required minLength={2} placeholder="Your full name"/></label>}
      <label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" required placeholder="you@example.com"/></label>
      {mode!=="reset" && <label>Password <span className="password-wrap"><input type={showPassword?"text":"password"} value={password} onChange={e=>setPassword(e.target.value)} autoComplete={mode==="login"?"current-password":"new-password"} required minLength={mode==="signup"?8:1} placeholder={mode==="signup"?"At least 8 characters":"Your password"}/><button type="button" onClick={()=>setShowPassword(!showPassword)} aria-label="Toggle password visibility">{showPassword?<EyeOff size={17}/>:<Eye size={17}/>}</button></span></label>}
      {mode==="signup" && <fieldset><legend>I’m joining as a</legend><button type="button" className={`role-choice ${role==="student"?"selected":""}`} onClick={()=>setRole("student")}><GraduationCap size={19}/><span><b>Student</b><small>Learn and request help</small></span></button><button type="button" className={`role-choice ${role==="tutor"?"selected":""}`} onClick={()=>setRole("tutor")}><Users size={19}/><span><b>Tutor</b><small>Share subjects you teach</small></span></button></fieldset>}
      <button className="auth-submit" disabled={busy}>{busy?"Please wait…":mode==="login"?"Sign in":mode==="signup"?"Create account":"Send reset link"}</button>
    </form>
    {mode==="login" && <button className="auth-link" onClick={()=>{setMode("reset");setError("");setMessage("");}}>Forgot password?</button>}
    <div className="auth-switch">{mode==="login"?"New to Brotherlly Hub?":mode==="signup"?"Already have an account?":"Remembered your password?"} <button onClick={()=>{setMode(mode==="login"?"signup":"login");setError("");setMessage("");}}>{mode==="login"?"Create account":"Sign in"}</button></div>
    <div className="auth-security"><ShieldCheck size={16}/> Passwords are managed by Firebase Authentication. Brotherlly Hub never stores your password directly.</div>
    <div className="auth-brand"><BookOpen size={15}/> Built for Nigerian learners</div>
  </section></main>;
}
export default function AuthGate({children}:{children:React.ReactNode}) {
  return <AuthProvider><AuthGateInner>{children}</AuthGateInner></AuthProvider>;
}
function AuthGateInner({children}:{children:React.ReactNode}) {
  const {user,profile,loading}=useAuth();
  // Render the sign-in UI when no authenticated profile is available.
  if (loading) return <main className="auth-page"><div className="auth-card">Loading your secure student space…</div></main>;
  if (!user || !profile) return <AuthScreen/>;
  return <>{!user.emailVerified && <div className="verification-banner"><span>Verify your email to use Brotherly AI and request tutoring sessions.</span><button onClick={async()=>{try{await sendEmailVerification(user);alert("Verification email sent. Check your inbox and spam folder.");}catch{alert("Could not send the email right now. Please try again later.");}}}>Resend verification email</button><button onClick={async()=>{await user.reload();await user.getIdToken(true);window.location.reload();}}>I verified — refresh</button></div>}{children}</>;
}
