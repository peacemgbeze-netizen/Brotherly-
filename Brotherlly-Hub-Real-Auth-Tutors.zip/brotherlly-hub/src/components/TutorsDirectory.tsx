 "use client";
import { FormEvent, useEffect, useState } from "react";
import { addDoc, collection, getDocs, query, where, serverTimestamp, updateDoc, doc } from "firebase/firestore";
import { db } from "../lib/firebase";
import { useAuth } from "../lib/auth-context";
import { CalendarClock, GraduationCap, LoaderCircle, Send, ShieldCheck, Users } from "lucide-react";

type Tutor = { uid:string; name:string; email:string; bio?:string; subjects?:string[] };
export default function TutorsDirectory({notify}:{notify:(message:string)=>void}) {
  const {user,profile}=useAuth();
  const [tutors,setTutors]=useState<Tutor[]>([]);
  const [loading,setLoading]=useState(true);
  const [busy,setBusy]=useState("");
  const [subject,setSubject]=useState("Mathematics");
  const [note,setNote]=useState("");
  const [editBio,setEditBio]=useState(profile?.bio||"");
  const [editSubjects,setEditSubjects]=useState((profile?.subjects||[]).join(", "));
  const [saving,setSaving]=useState(false);
  const [incoming,setIncoming]=useState<Array<{id:string;requesterName:string;subject:string;note:string;status:string;createdAt?:unknown}>>([]);
  async function loadTutors() {
    setLoading(true);
    try {
      const snap=await getDocs(query(collection(db,"profiles"),where("role","==","tutor"),where("tutorApproved","==",true)));
      setTutors(snap.docs.map(d=>d.data() as Tutor).filter(t=>t.uid!==user?.uid));
      if(profile?.role==="tutor" && user) {
        const requests=await getDocs(query(collection(db,"sessionRequests"),where("tutorUid","==",user.uid)));
        setIncoming(requests.docs.map(d=>({id:d.id,...d.data()} as {id:string;requesterName:string;subject:string;note:string;status:string;createdAt?:unknown})).sort((a,b)=>String(b.createdAt??"").localeCompare(String(a.createdAt??""))));
      }
    } catch { notify("Could not load tutors. Check your Firestore rules and connection."); }
    finally {setLoading(false);}
  }
  useEffect(()=>{void loadTutors();},[]);
  async function requestSession(tutor:Tutor) {
    if(!user || !profile) return;
    if(!user.emailVerified) {notify("Verify your email before requesting a tutoring session.");return;}
    setBusy(tutor.uid);
    try {
      await addDoc(collection(db,"sessionRequests"),{
        requesterUid:user.uid,requesterName:profile.name,requesterEmail:user.email,
        tutorUid:tutor.uid,tutorName:tutor.name,subject,note:note.trim(),
        status:"pending",createdAt:serverTimestamp(),updatedAt:serverTimestamp()
      });
      notify(`Session request sent to ${tutor.name}. You can follow up from your account.`);
      setNote("");
    } catch {notify("Request failed. Check Firestore rules and try again.");}
    finally {setBusy("");}
  }
  async function updateRequest(id:string,status:"accepted"|"declined") {
    try {
      await updateDoc(doc(db,"sessionRequests",id),{status,updatedAt:serverTimestamp()});
      setIncoming(prev=>prev.map(r=>r.id===id?{...r,status}:r));
      notify(status==="accepted"?"Session request accepted. Contact the student through your agreed safe channel.":"Session request declined.");
    } catch { notify("Could not update this request. Check your connection and permissions."); }
  }
  async function saveTutorProfile(e:FormEvent) {
    e.preventDefault();
    if(!user || !profile) return;
    if(!user.emailVerified) {notify("Verify your email before publishing a tutor profile.");return;}
    setSaving(true);
    try {
      await updateDoc(doc(db,"profiles",user.uid),{bio:editBio.trim(),subjects:editSubjects.split(",").map(s=>s.trim()).filter(Boolean).slice(0,12)});
      notify("Tutor profile updated.");
      await loadTutors();
    } catch(e) {notify(e instanceof Error?e.message:"Could not save profile.");}
    finally {setSaving(false);}
  }
  return <section className="tutors-page">
    <div className="tutors-hero"><div><span className="tutors-kicker"><Users size={15}/> STUDENT CONNECTIONS</span><h1>Learn with a real tutor.</h1><p>Find people who teach your subjects and send a real session request. Requests are stored in your account system, not just displayed on screen.</p></div><div className="tutors-hero-icon"><GraduationCap size={42}/></div></div>
    {profile?.role==="tutor" && !profile.tutorApproved && <div className="tutor-profile-editor"><h2>Tutor profile review</h2><p>Your tutor profile is not public yet. For student safety, a tutor account must be reviewed and approved by the Brotherlly Hub administrator before it can appear in search or receive requests.</p></div>}
    {profile?.role==="tutor" && profile.tutorApproved && <form className="tutor-profile-editor" onSubmit={saveTutorProfile}><h2>Your tutor profile</h2><p>Tell students what you teach. Use commas between subjects.</p><label>Short introduction<textarea value={editBio} onChange={e=>setEditBio(e.target.value)} maxLength={500} required placeholder="Explain your experience and teaching style."/></label><label>Subjects taught<input value={editSubjects} onChange={e=>setEditSubjects(e.target.value)} maxLength={240} required placeholder="Mathematics, Biology, Chemistry"/></label><button className="btn-primary" disabled={saving}>{saving?"Saving…":"Publish profile"}</button></form>}
    {profile?.role==="tutor" && profile.tutorApproved && <section className="tutor-profile-editor"><h2>Incoming session requests</h2><p>Review requests sent to your tutor account.</p>{incoming.length===0?<p className="request-empty">No requests yet. Your new requests will appear here.</p>:<div className="incoming-list">{incoming.map(r=><article className="incoming-request" key={r.id}><div><strong>{r.requesterName}</strong><span>{r.subject} · <b className={`request-status ${r.status}`}>{r.status}</b></span><p>{r.note||"No message included."}</p></div>{r.status==="pending"&&<div className="request-actions"><button onClick={()=>void updateRequest(r.id,"accepted")}>Accept</button><button onClick={()=>void updateRequest(r.id,"declined")}>Decline</button></div>}</article>)}</div>}</section>}
    <div className="tutor-search-row"><div><h2>Available tutors</h2><p>Profiles are provided by registered users.</p></div><label>Request subject<select value={subject} onChange={e=>setSubject(e.target.value)}>{["Mathematics","English Language","Biology","Chemistry","Physics","Economics","Government","Literature","Computer Studies","Other"].map(x=><option key={x}>{x}</option>)}</select></label></div>
    {loading?<div className="tutor-empty"><LoaderCircle className="spin"/><p>Loading registered tutor profiles…</p></div>:tutors.length===0?<div className="tutor-empty"><GraduationCap size={34}/><h3>No tutor profiles yet</h3><p>When tutors register, verify their email, and publish their profile, they will appear here.</p></div>:<div className="tutor-grid">{tutors.map(t=><article className="tutor-card" key={t.uid}><div className="tutor-avatar">{(t.name||"T").slice(0,1).toUpperCase()}</div><div className="tutor-verified"><ShieldCheck size={14}/> Registered account</div><h3>{t.name}</h3><p className="tutor-bio">{t.bio||"This tutor has not added an introduction yet."}</p><div className="tutor-subjects">{(t.subjects?.length?t.subjects:["Subjects not listed"]).map(x=><span key={x}>{x}</span>)}</div><label>Message / learning goal<textarea value={note} onChange={e=>setNote(e.target.value)} maxLength={500} placeholder="What topic would you like help with?"/></label><button className="btn-primary" onClick={()=>void requestSession(t)} disabled={busy===t.uid}>{busy===t.uid?"Sending…":<><CalendarClock size={15}/> Request session <Send size={14}/></>}</button></article>)}</div>}
    <p className="tutors-disclaimer">Session requests are not confirmed bookings. The tutor must review and accept the request before a session is agreed.</p>
  </section>;
}
